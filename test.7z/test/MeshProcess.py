﻿from fbx import FbxMesh, FbxNode, FbxVector2, FbxVector4, FbxExporter, FbxManager, FbxScene, FbxLayerElementVertexColor, \
    FbxLayerElement, FbxColor
import pandas as pd
import FbxCommon
import os


def load_csv_file(file_path: str):
    with open(file_path, "r") as csvfile:
        data = pd.read_csv(file_path)
        return data


def set_vertices(mesh: FbxMesh, whole_data: pd.DataFrame, id_start=2, scale=100):
    for i in range(len(whole_data)):
        row = whole_data.iloc[i]
        vertex = FbxVector4(row.iloc[id_start].item(),
                            row.iloc[id_start + 1].item(),
                            row.iloc[id_start + 2].item())
        vertex *= scale
        mesh.SetControlPointAt(vertex, int(row.iloc[1]))


def set_triangles(mesh: FbxMesh, whole_data: pd.DataFrame):
    for i in range(0, len(whole_data), 3):
        mesh.BeginPolygon(int(i / 3))
        mesh.AddPolygon(whole_data.iloc[i, 1].item())
        mesh.AddPolygon(whole_data.iloc[i + 1, 1].item())
        mesh.AddPolygon(whole_data.iloc[i + 2, 1].item())
        mesh.EndPolygon()


def set_normals(mesh: FbxMesh, whole_data: pd.DataFrame, normal_start=5):
    normal = mesh.CreateElementNormal()
    normal.SetMappingMode(FbxLayerElement.EMappingMode.eByControlPoint)
    normal.SetReferenceMode(FbxLayerElement.EReferenceMode.eDirect)
    for i in range(len(whole_data)):
        row = whole_data.iloc[i]
        target_index = int(row.iloc[1])
        vertex_normal = FbxVector4(row.iloc[normal_start].item(),
                                   row.iloc[normal_start + 1].item(),
                                   row.iloc[normal_start + 2].item())
        mesh.SetControlPointNormalAt(vertex_normal, target_index)


# TODO: I could not confirm whether it worked
def set_tangents(mesh: FbxMesh, whole_data: pd.DataFrame, tangent_start=8):
    tangent = mesh.CreateElementTangent()
    tangent.SetMappingMode(FbxLayerElement.EMappingMode.eByControlPoint)
    tangent.SetReferenceMode(FbxLayerElement.EReferenceMode.eDirect)
    tangent_array = tangent.GetDirectArray()
    tangent_array.Resize(int(len(whole_data) / 3))
    for i in range(len(whole_data)):
        row = whole_data.iloc[i]
        target_index = int(row.iloc[1])
        vertex_tangent = FbxVector4(row.iloc[tangent_start].item(),
                                    row.iloc[tangent_start + 1].item(),
                                    row.iloc[tangent_start + 2].item(),
                                    row.iloc[tangent_start + 3].item())
        # mesh.SetControlPointTangent(vertex_tangent, target_index)
        tangent_array.SetAt(target_index, vertex_tangent)


'''
    vertex color mapping mode must be eByPolygonVertex
    and reference mode must be eByControlPoint
    other wise it will be invalidate color
'''
def set_colors(mesh: FbxMesh, whole_data: pd.DataFrame, colors_start=12):
    color = mesh.CreateElementVertexColor()
    color.SetMappingMode(FbxLayerElement.EMappingMode.eByPolygonVertex)
    color.SetReferenceMode(FbxLayerElement.EReferenceMode.eIndexToDirect)
    color_array = color.GetDirectArray()
    color_array.Resize(int(len(whole_data) / 3))
    color_index = color.GetIndexArray()
    color_index.Resize(int(len(whole_data)))
    for i in range(len(whole_data)):
        row = whole_data.iloc[i]
        target_index = int(row.iloc[1])
        vertex_color = FbxColor(row.iloc[colors_start].item(),
                                row.iloc[colors_start + 1].item(),
                                row.iloc[colors_start + 2].item(),
                                row.iloc[colors_start + 3].item())
        color_array.SetAt(target_index, vertex_color)
        color_index.SetAt(i, target_index)


def set_uvs(mesh: FbxMesh, whole_data: pd.DataFrame, uv_num=0, uv_start=16):
    index_num = len(whole_data)
    uv = mesh.CreateElementUV(f"uv_{uv_num}")
    uv.SetMappingMode(FbxLayerElement.EMappingMode.eByPolygonVertex)
    uv.SetReferenceMode(FbxLayerElement.EReferenceMode.eIndexToDirect)
    direct_array = uv.GetDirectArray()
    index_array = uv.GetIndexArray()
    direct_array.Resize(int(index_num / 3))
    index_array.Resize(index_num)
    for j in range(index_num):
        row = whole_data.iloc[j]
        target_index = int(row.iloc[1])
        uv_coord = FbxVector2(row.iloc[uv_start].item(),
                              row.iloc[uv_start+ 1].item())
        direct_array.SetAt(target_index, uv_coord)
        index_array.SetAt(j, target_index)


def export_fbx(manager: FbxManager, scene: FbxScene, save_path: str):
    exporter = FbxExporter.Create(manager, "")
    is_initialized = exporter.Initialize(save_path)
    if not is_initialized:
        raise Exception('Exporter failed to initialize. Error returned: ' + str(exporter.GetStatus().GetErrorString()))
    exporter.Export(scene)
    exporter.Destroy()


def get_csv_files(folder_path: str) -> list:
    extension = '.csv'
    file_list = []
    for root, dirs, files in os.walk(folder_path):
        root = root.replace('\\', '/')
        for file in files:
            if file.endswith(extension):
                full_path = f"{root}/{file}"
                file_list.append(full_path)
    return file_list


def convert_csv_to_fbx(export_dict:dict,csv_path: str, save_path: str, scale=100):
    export_file_name = os.path.splitext(os.path.basename(csv_path))[0]
    save_path = f"{save_path}/{export_file_name}.fbx"
    manager, scene = FbxCommon.InitializeSdkObjects()
    mesh = FbxMesh.Create(manager, export_file_name)
    node = FbxNode.Create(manager, export_file_name)
    node.SetNodeAttribute(mesh)
    scene.GetRootNode().AddChild(node)
    # csv_path "C:/Users/wangwei61/Documents/gun.csv"
    csv_data = load_csv_file(csv_path)
    set_vertices(mesh, csv_data, 2, scale)
    set_triangles(mesh, csv_data)

    if 'NORMAL' in export_dict:
        set_normals(mesh, csv_data, export_dict['NORMAL'])
        print('NORMAL')
    if 'TANGENT' in export_dict:
        set_tangents(mesh, csv_data, export_dict['TANGENT'])
        print('TANGENT')
    if 'COLOR' in export_dict:
        set_colors(mesh, csv_data, export_dict['COLOR'])
        print('COLOR')
    if 'UV0' in export_dict:
        set_uvs(mesh, csv_data, 0,export_dict['UV0'])
        print('UV0')
    if 'UV1' in export_dict:
        set_uvs(mesh, csv_data, 1,export_dict['UV1'])
        print('UV1')
    if 'UV2' in export_dict:
        set_uvs(mesh, csv_data, 2,export_dict['UV2'])
        print('UV2')
    export_fbx(manager, scene, save_path)


def convert_whole_folder(export_dict:dict,fold_path: str, save_path: str, scale=100):
    file_paths = get_csv_files(fold_path)
    for file_path in file_paths:
        convert_csv_to_fbx(export_dict,file_path, save_path, scale)
    print("Finished converting whole folder")

