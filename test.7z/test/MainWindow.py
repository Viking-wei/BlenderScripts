import sys
from PyQt6.QtWidgets import QApplication, QTableWidgetItem
from PyQt6.QtCore import Qt
from PyQt6 import uic
from qframelesswindow import FramelessWindow
from qfluentwidgets import SplitFluentWindow, FluentIcon
from Subwindow import ImportWindow, ConfigOutputWindow, ExportLogWindow
from MeshProcess import get_csv_files, load_csv_file
from Utilites import match_keywords

INPUT_PATH = ''
SELECTABLE_MATCH_LIST = ['NORMAL', 'TANGENT', 'COLOR', 'UV0', 'UV1', 'UV2', 'UV3']
ESSENTIAL_OUTPUT_DICT = {}
SHOW_LIST = []


class Converter(SplitFluentWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CSV Converter")
        self.resize(800, 600)

        self.importWindow = ImportWindow(self)
        self.addSubInterface(self.importWindow, FluentIcon.ALBUM, '预处理')

        self.configOutputWindow = ConfigOutputWindow(self)
        self.addSubInterface(self.configOutputWindow, FluentIcon.AIRPLANE, '配置参数')

        self.exportLogWindow = ExportLogWindow(self)
        self.addSubInterface(self.exportLogWindow, FluentIcon.ACCEPT, '日志')

        self.importWindow.preResolve.clicked.connect(lambda: self.pre_resolve((self.importWindow.pathString.text()),
                                                                              self.configOutputWindow.NORMAL,
                                                                              self.configOutputWindow.TANGENT,
                                                                              self.configOutputWindow.COLOR,
                                                                              self.configOutputWindow.UV0,
                                                                              self.configOutputWindow.UV1,
                                                                              self.configOutputWindow.UV2))
        self.configOutputWindow.exportButton.clicked.connect(
            lambda: self.configOutputWindow.final_export(ESSENTIAL_OUTPUT_DICT,
                                                         INPUT_PATH))

    def pre_resolve(self, path, *combos):
        global ESSENTIAL_OUTPUT_DICT, SHOW_LIST, INPUT_PATH
        if not path:
            self.importWindow.show_error("未添加路径")
            return
        files = get_csv_files(path)
        if len(files) == 0:
            self.importWindow.show_error("指定路径中没有CSV文件")
            return
        INPUT_PATH = path
        first_csv_data = load_csv_file(files[0])
        origin_titles = first_csv_data.columns.tolist()
        ESSENTIAL_OUTPUT_DICT = match_keywords(origin_titles, SELECTABLE_MATCH_LIST)
        print(ESSENTIAL_OUTPUT_DICT)
        matched_titles = list(ESSENTIAL_OUTPUT_DICT.keys())
        SHOW_LIST = []
        for title in origin_titles:
            cur = title.strip().split('.', 1)[0]
            if not SHOW_LIST:
                SHOW_LIST.append(cur)
                continue
            pre = SHOW_LIST[-1]
            if cur != pre:
                SHOW_LIST.append(cur)
        SHOW_LIST = SHOW_LIST[3:]
        SHOW_LIST.append('None')
        none_index = len(SHOW_LIST) - 1
        for combo in combos:
            combo.clear()
        for combo in combos:
            show_index = none_index
            combo.addItems(SHOW_LIST)
            for i in range(len(matched_titles)):
                if combo.objectName() == matched_titles[i]:
                    print(combo.objectName())
                    show_index = i
                    break
            combo.setCurrentIndex(show_index)
        print(matched_titles)
        print(SHOW_LIST)
        temp={}
        for i in range(len(matched_titles)):
            temp[SHOW_LIST[i]] = ESSENTIAL_OUTPUT_DICT[matched_titles[i]]
        ESSENTIAL_OUTPUT_DICT=temp
        print("ESSENTIAL_OUTPUT_DICT")
        print(ESSENTIAL_OUTPUT_DICT)
        self.importWindow.show_correct()


if __name__ == '__main__':
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    ui = Converter()
    ui.show()
    sys.exit(app.exec())
