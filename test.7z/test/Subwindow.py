from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QWidget
import First, Second, Third
import sys
import re
import tkinter as tk
from pathlib import Path
from tkinter import filedialog
from qfluentwidgets import Flyout, InfoBarIcon
from MeshProcess import convert_whole_folder


class ImportWindow(QWidget, First.Ui_Form1):
    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.setupUi(self)
        self.importButton.clicked.connect(lambda: select_path(self.pathString))

    def show_correct(self):
        Flyout.create(
            icon=InfoBarIcon.SUCCESS,
            title='解析成功！',
            content="接下来去配置参数吧",
            target=self.preResolve,
            parent=self,
            isClosable=True
        )

    def show_error(self, reason: str):
        Flyout.create(
            icon=InfoBarIcon.ERROR,
            title='解析失败！',
            content=reason,
            target=self.preResolve,
            parent=self,
            isClosable=True
        )


class ConfigOutputWindow(QWidget, Second.Ui_Form2):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.outputButton.clicked.connect(lambda: select_path(self.pathString))
        self.progressBar.setVisible(False)

    def get_selectable_list(self) -> list:
        result = [self.normalCheck.isChecked(),
                  self.tangentCheck.isChecked(),
                  self.colorCheck.isChecked(),
                  self.uv0Check.isChecked(),
                  self.uv1Check.isChecked(),
                  self.uv2Check.isChecked()]
        return result

    def get_associated_list(self) -> list:
        result = [self.NORMAL.currentText(),
                  self.TANGENT.currentText(),
                  self.COLOR.currentText(),
                  self.UV0.currentText(),
                  self.UV1.currentText(),
                  self.UV2.currentText()]
        return result

    def get_combo_name_list(self) -> list:
        result = [self.NORMAL.objectName(),
                  self.TANGENT.objectName(),
                  self.COLOR.objectName(),
                  self.UV0.objectName(),
                  self.UV1.objectName(),
                  self.UV2.objectName()]
        return result

    def show_correct(self):
        Flyout.create(
            icon=InfoBarIcon.SUCCESS,
            title='导出成功！',
            content="",
            target=self.exportButton,
            parent=self,
            isClosable=True
        )

    def show_error(self, reason: str):
        Flyout.create(
            icon=InfoBarIcon.ERROR,
            title='导出失败！',
            content=reason,
            target=self.exportButton,
            parent=self,
            isClosable=True
        )

    def final_export(self, export_dict: dict, import_path: str):
        if not is_valid_path(self.pathString.text()):
            self.show_error("非法路径")
            return
        is_need_export_list = self.get_selectable_list()
        custom_export_list = self.get_associated_list()
        combo_name_list = self.get_combo_name_list()
        print("debug")
        print("is_need_export_list")
        print(is_need_export_list)
        print("custom_export_list")
        print(custom_export_list)
        print("combo_name_list")
        print(combo_name_list)
        print('export_dict')
        print(export_dict)
        final_export_dict = {}
        for i in range(len(is_need_export_list)):
            if is_need_export_list[i]:
                if custom_export_list[i] in export_dict:
                    final_export_dict[combo_name_list[i]] = export_dict[custom_export_list[i]]
                else:
                    self.show_error("None字段无法被导出")
                    return
        print("final_export_dict")
        print(final_export_dict)
        convert_whole_folder(final_export_dict, import_path, self.pathString.text())
        self.show_correct()


class ExportLogWindow(QWidget, Third.Ui_Form3):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)


def select_path(path_string):
    root = tk.Tk()
    root.withdraw()
    selected_directory = filedialog.askdirectory()
    path_string.setText(selected_directory)
    print("Selected directory:", selected_directory)


def match(origin_list: list, match_list: list) -> list:
    pass


def is_valid_path(path)->bool:
    if not path:
        return False

    # if not re.match(r'^[a-zA-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*$', path):
    #     return False

    if len(path) > 260:
        return False

    try:
        path_obj = Path(path)
        if not path_obj.is_absolute():
            return False

        path_obj.resolve(strict=True)
        return True
    except (OSError, RuntimeError):
        return False