﻿def get_pure_up_prefix(target: str) -> str:
    pure = target.split('.')[0]
    return pure.upper()


def get_pure_low_suffix(target: str) -> str:
    pure = target.split('.')[-1]
    return pure.lower()


def str_match_mode(origin: list, match: list):
    start_pos = 5
    result = {}
    for i in range(start_pos, len(origin)):
        for mc in match:
            if get_pure_up_prefix(origin[i]) == mc and not result.__contains__(mc):
                result[mc] = i
                break
    return result


def guess_match_mode(origin: list, match: list):
    result = {}
    match_start_count = 0
    letter_dict = {'x': 0, 'y': 1, 'z': 2, 'w': 3}
    for i in range(5, len(origin)):
        current_index = letter_dict[get_pure_low_suffix(origin[i])]
        if i + 1 >= len(origin):
            result[match[match_start_count]] = i - current_index
            break
        next_index = letter_dict[get_pure_low_suffix(origin[i + 1])]
        if current_index > next_index:
            if current_index == 3 and match_start_count == 0:
                match_start_count += 1
            if current_index == 1 and 'COLOR' not in result:
                match_start_count += 1
            result[match[match_start_count]] = i - current_index
            match_start_count += 1
    return result


def match_keywords(origin: list, match: list):
    test = str_match_mode(origin, match)
    if test:
        return test
    return guess_match_mode(origin, match)


if __name__ == '__main__':
    origin = ['VTX', 'IDX', 'POSITION.x', 'POSITION.y', 'POSITION.z', 'NORMAL.x', 'NORMAL.y', 'NORMAL.z', 'TANGENT.x',
              'TANGENT.y', 'TANGENT.z', 'TANGENT.w', 'TANGENT.x', 'TANGENT.y', 'TANGENT.z', 'TANGENT.w', 'COLOR.x',
              'COLOR.y']
    match = ['NORMAL', 'TANGENT', 'COLOR', 'UV0', 'UV1', 'UV2']
    print(guess_match_mode(origin, match))
